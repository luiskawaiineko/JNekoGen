import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GenLauncher {
    public GenLauncher(Rectangle windowData)
    {
        JFrame f = new JFrame("JavaGen Suite 0.3 Alpha");

        JButton pojoGenButton = new JButton("PojoGen");
        JButton fxGenButton = new JButton("FxGen");

        pojoGenButton.setBounds(3,3,300,40);
        fxGenButton.setBounds(307,3,300,40);

        pojoGenButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                PojoGen pojoGen = new PojoGen(f.getBounds());
                f.dispose();
            }
        });
        fxGenButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                FxGen fxGen = new FxGen(f.getBounds());
                f.dispose();
            }
        });
        f.add(pojoGenButton);
        f.add(fxGenButton);
        f.setResizable(false);
        f.setBounds(windowData);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class PojoGen {
    private JTextField labelCustom;
    private JTextField fieldInt;
    private JTextField fieldString;
    private JTextField fieldDate;
    private JTextField fieldDouble;
    private JTextField fieldBoolean;
    private JTextField fieldCustom;

    public PojoGen(Rectangle windowData)  {
        JFrame f = new JFrame("PojoGen");
        JLabel labelInt = new JLabel();
        JLabel labelString = new JLabel();
        JLabel labelDate = new JLabel();
        JLabel labelDouble = new JLabel();
        JLabel labelBoolean = new JLabel();

        labelCustom = new JTextField();
        fieldInt = new JTextField();
        fieldString = new JTextField();
        fieldDate = new JTextField();
        fieldDouble = new JTextField();
        fieldBoolean = new JTextField();
        fieldCustom = new JTextField();

        JTextArea output = new JTextArea();
        JButton resetButton = new JButton("Clear");
        JScrollPane scroll = new JScrollPane (output);
        TextPrompt placeholder = new TextPrompt("Custom class", labelCustom);

        labelInt.setText("Int");
        labelString.setText("String");
        labelDate.setText("Date");
        labelDouble.setText("Double");
        labelBoolean.setText("Boolean");

        labelInt.setBounds(5, 20, 100, 20);
        labelString.setBounds(105, 20, 100, 20);
        labelDate.setBounds(205, 20, 100, 20);
        labelDouble.setBounds(305, 20, 100, 20);
        labelBoolean.setBounds(405, 20, 100, 20);
        labelCustom.setBounds(505, 20, 100, 20);

        fieldInt.setBounds(5, 50, 100, 20);
        fieldString.setBounds(105, 50, 100, 20);
        fieldDate.setBounds(205, 50, 100, 20);
        fieldDouble.setBounds(305, 50, 100, 20);
        fieldBoolean.setBounds(405, 50, 100, 20);
        fieldCustom.setBounds(505, 50, 100, 20);

        scroll.setBounds(5, 80, 600, 350);
        resetButton.setBounds(5, 435, 600, 45);

        Vector<Component> components = new Vector<Component>(7);
        components.add(labelCustom);
        components.add(fieldInt);
        components.add(fieldDate);
        components.add(fieldDouble);
        components.add(fieldBoolean);
        components.add(fieldCustom);
        components.add(fieldString);

        f.setFocusTraversalPolicy(new CustomFocusTraversalPolicy(components));
        f.setResizable(false);
        f.add(labelInt);
        f.add(labelString);
        f.add(labelDate);
        f.add(labelDouble);
        f.add(labelBoolean);
        f.add(labelCustom);

        f.add(fieldInt);
        f.add(fieldString);
        f.add(fieldDate);
        f.add(fieldDouble);
        f.add(fieldBoolean);
        f.add(fieldCustom);
        f.add(resetButton);

        placeholder.changeAlpha(0.75f);
        placeholder.changeStyle(Font.ITALIC);

        scroll.getViewport().setBackground(Color.white);
        output.setEditable(false);
        f.add(scroll);
        f.setBounds(windowData);
        f.setLayout(null);
        f.setVisible(true);


        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                GenLauncher launcher = new GenLauncher(f.getBounds());
                f.dispose();
            }
        });
        resetButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                UIManager.put("OptionPane.yesButtonText", "Yes");
                UIManager.put("OptionPane.NoButtonText", "No");
                if (JOptionPane.showConfirmDialog(null, "Are you sure that you want to clear the output?","Confirm, please.",JOptionPane.YES_NO_OPTION) == 0) {
                    output.setText("");
                }

            }
        });

        fieldInt.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldInt.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private int "+fieldInt.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate int "+fieldInt.getText()+";");
                    }
                    fieldInt.setText("");
                }
            }

        });

        fieldString.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldString.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private String "+fieldString.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate String "+fieldString.getText()+";");
                    }
                    fieldString.setText("");
                }
            }

        });

        fieldDate.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldDate.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private LocalDate "+fieldDate.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate LocalDate "+fieldDate.getText()+";");
                    }
                    fieldDate.setText("");
                }
            }

        });

        fieldBoolean.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldBoolean.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private boolean "+fieldBoolean.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate boolean "+fieldBoolean.getText()+";");
                    }
                    fieldBoolean.setText("");
                }
            }

        });

        fieldDouble.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldDouble.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private double "+fieldDouble.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate double "+fieldDouble.getText()+";");
                    }
                    fieldDouble.setText("");
                }
            }
        });

        fieldCustom.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldCustom.getText().equals("")){
                    if (labelCustom.getText().equals(""))
                    {
                        JOptionPane.showMessageDialog(null, "Error: You must insert a name in the custom class");
                    }
                    else {
                        String customClass = labelCustom.getText().substring(0, 1).toUpperCase() + labelCustom.getText().substring(1).toLowerCase();
                        if (output.getText().equals("")) {
                            output.append("private " + customClass + " " + fieldCustom.getText() + ";");
                        } else {
                            output.append("\nprivate " + customClass + " " + fieldCustom.getText() + ";");
                        }
                        fieldCustom.setText("");
                        labelCustom.setText("");
                    }
                }
            }
        });
    }
    private class CustomFocusTraversalPolicy extends FocusTraversalPolicy {
        Vector<Component> components;

        public CustomFocusTraversalPolicy(Vector<Component> componentsInput) {
            components = componentsInput;
        }

        public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldInt)) {
                return fieldString;
            } else if (aComponent.equals(fieldString)) {
                return fieldDate;
            } else if (aComponent.equals(fieldDate)) {
                return fieldDouble;
            } else if (aComponent.equals(fieldDouble)) {
                return fieldBoolean;
            } else if (aComponent.equals(fieldBoolean)) {
                return labelCustom;
            }
            else if (aComponent.equals(labelCustom)) {
                return fieldCustom;
            }
            else if (aComponent.equals(fieldCustom)) {
                return fieldInt;
            }
            return fieldInt;
        }

        public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldInt)) {
                return fieldCustom;
            } else if (aComponent.equals(fieldCustom)) {
                return labelCustom;
            } else if (aComponent.equals(labelCustom)) {
                return fieldBoolean;
            } else if (aComponent.equals(fieldBoolean)) {
                return fieldDouble;
            } else if (aComponent.equals(fieldDouble)) {
                return fieldDate;
            }
            else if (aComponent.equals(fieldDate)) {
                return fieldString;
            }
            else if (aComponent.equals(fieldString)) {
                return fieldInt;
            }

            return fieldInt;
        }

        public Component getDefaultComponent(Container focusCycleRoot) {
            return fieldInt;
        }

        public Component getLastComponent(Container focusCycleRoot) {
            return fieldCustom;
        }

        public Component getFirstComponent(Container focusCycleRoot) {
            return fieldInt;
        }
    }

}
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class FxGen {
    private JTextField fieldMain;
    private JTextField fieldPrincipal;
    private String outString;

    public FxGen(Rectangle windowData)  {
        JFrame f = new JFrame("Easy Pojo Generator by Luis Miguel Congosto");
        JLabel labelInt = new JLabel();
        JLabel labelString = new JLabel();

        fieldMain = new JTextField();
        fieldPrincipal = new JTextField();

        JTextArea output = new JTextArea();
        JButton resetButton = new JButton("Clear");
        JScrollPane scroll = new JScrollPane (output);
        labelInt.setText("Principal Screen Name");
        labelString.setText("New Screen Name");

        labelInt.setBounds(5, 20, 200, 20);
        labelString.setBounds(205, 20, 200, 20);

        fieldMain.setBounds(5, 50, 200, 20);
        fieldPrincipal.setBounds(205, 50, 200, 20);


        scroll.setBounds(5, 80, 600, 350);
        resetButton.setBounds(5, 435, 600, 45);

        Vector<Component> components = new Vector<Component>(7);
        components.add(fieldMain);
        components.add(fieldPrincipal);

        f.setFocusTraversalPolicy(new CustomFocusTraversalPolicy(components));
        f.setResizable(false);
        f.add(labelInt);
        f.add(labelString);

        f.add(fieldMain);
        f.add(fieldPrincipal);
        f.add(resetButton);

        scroll.getViewport().setBackground(Color.white);
        output.setEditable(false);
        f.add(scroll);
        f.setBounds(windowData);
        f.setLayout(null);
        f.setVisible(true);


        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                GenLauncher launcher = new GenLauncher(f.getBounds());
                f.dispose();
            }
        });
        resetButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                UIManager.put("OptionPane.yesButtonText", "Yes");
                UIManager.put("OptionPane.NoButtonText", "No");
                if (JOptionPane.showConfirmDialog(null, "Are you sure that you want to clear the output?","Confirm, please.",JOptionPane.YES_NO_OPTION) == 0) {
                    output.setText("");
                }

            }
        });

        fieldMain.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldMain.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private int "+ fieldMain.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate int "+ fieldMain.getText()+";");
                    }
                    fieldMain.setText("");
                }
            }

        });

        fieldPrincipal.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldPrincipal.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private String "+ fieldPrincipal.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate String "+ fieldPrincipal.getText()+";");
                    }
                    fieldPrincipal.setText("");
                }
            }

        });
    }
    private class CustomFocusTraversalPolicy extends FocusTraversalPolicy {
        Vector<Component> components;

        public CustomFocusTraversalPolicy(Vector<Component> componentsInput) {
            components = componentsInput;
        }

        public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldMain)) {
                return fieldPrincipal;
            } else if (aComponent.equals(fieldPrincipal)) {
                return fieldMain;
            }
            return fieldMain;
        }

        public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldMain)) {
                return fieldPrincipal;
            }
            else if (aComponent.equals(fieldPrincipal)) {
                return fieldMain;
            }

            return fieldMain;
        }

        public Component getDefaultComponent(Container focusCycleRoot) {
            return fieldMain;
        }

        public Component getLastComponent(Container focusCycleRoot) {
            return fieldPrincipal;
        }

        public Component getFirstComponent(Container focusCycleRoot) {
            return fieldMain;
        }
    }

}
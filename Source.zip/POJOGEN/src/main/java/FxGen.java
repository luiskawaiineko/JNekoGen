import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class FxGen {
    private JTextField fieldTitle;
    private JTextField fieldMain;
    private JTextField fieldNew;
    private String outString;

    public FxGen(Rectangle windowData)  {
        JFrame f = new JFrame("FxGen");
        JLabel labelMain = new JLabel();
        JLabel labelNew = new JLabel();

        fieldTitle = new JTextField();
        fieldMain = new JTextField();
        fieldNew = new JTextField();

        TextPrompt placeHolderTitle = new TextPrompt("Window title", fieldTitle);
        TextPrompt placeHolderDefault = new TextPrompt("Leave blank for default", fieldMain);
        JTextArea output = new JTextArea();
        JButton resetButton = new JButton("Clear");
        JScrollPane scroll = new JScrollPane (output);
        labelMain.setText("Principal Screen Name");
        labelNew.setText("New Screen Name");

        labelMain.setBounds(5, 50, 200, 20);
        labelNew.setBounds(250, 20, 200, 20);

        fieldTitle.setBounds(5, 20, 200, 20);
        fieldMain.setBounds(5, 80, 200, 20);
        fieldNew.setBounds(250, 50, 200, 20);

        placeHolderTitle.changeAlpha(0.75f);
        placeHolderTitle.changeStyle(Font.ITALIC);
        placeHolderDefault.changeAlpha(0.75f);
        placeHolderDefault.changeStyle(Font.ITALIC);

        scroll.setBounds(5, 110, 600, 320);
        resetButton.setBounds(5, 435, 600, 45);

        Vector<Component> components = new Vector<Component>(7);
        components.add(fieldTitle);
        components.add(fieldMain);
        components.add(fieldNew);

        f.setFocusTraversalPolicy(new CustomFocusTraversalPolicy(components));
        f.setResizable(false);
        f.add(labelMain);
        f.add(labelNew);

        f.add(fieldTitle);
        f.add(fieldMain);
        f.add(fieldNew);
        f.add(resetButton);

        scroll.getViewport().setBackground(Color.white);
        output.setEditable(false);
        f.add(scroll);
        f.setBounds(windowData);
        f.setLayout(null);
        f.setVisible(true);


        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                GenLauncher launcher = new GenLauncher(f.getBounds());
                f.dispose();
            }
        });
        resetButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                UIManager.put("OptionPane.yesButtonText", "Yes");
                UIManager.put("OptionPane.NoButtonText", "No");
                if (JOptionPane.showConfirmDialog(null, "Are you sure that you want to clear the output?","Confirm, please.",JOptionPane.YES_NO_OPTION) == 0) {
                    output.setText("");
                }

            }
        });

        fieldMain.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    if (fieldMain.getText().equals(""))
                    {
                        fieldMain.setText("Principal.fxml");
                    }
                    if (fieldTitle.getText().equals(""))
                    {
                        JOptionPane.showMessageDialog(null, "Error: You must insert a title");
                    }
                    else
                    {
                        if (!fieldMain.getText().toLowerCase().endsWith(".fxml"))
                        {
                            fieldMain.setText(fieldMain.getText()+".fxml");
                        }
                        output.setText("FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource(\"/fxml/"+fieldMain.getText()+"\"));\n" +
                                "BorderPane root = loaderMenu.load();\n" +
                                "Scene scene = new Scene(root);\n" +
                                "primaryStage.setTitle(\""+fieldTitle.getText()+"\");\n" +
                                "primaryStage.setScene(scene);\n" +
                                "primaryStage.show();\n" +
                                "primaryStage.setResizable(false);");
                        fieldMain.setText("");
                    }
                }
            }

        });

        fieldNew.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldNew.getText().equals("")){
                    fieldNew.setText(fieldNew.getText().substring(0, 1).toUpperCase() + fieldNew.getText().substring(1).toLowerCase());
                    output.setText("//Before method\n" +
                            "FXMLLoader loader"+fieldNew.getText()+";\n" +
                            "AnchorPane pane"+fieldNew.getText()+";\n\n" +
                            "//Inside method\n" +
                            "if (pane"+fieldNew.getText()+" == null) {\n" +
                            "      loader"+fieldNew.getText()+" = new FXMLLoader();\n" +
                            "      pane"+fieldNew.getText()+" = loader"+fieldNew.getText()+".load(getClass().getResourceAsStream(\"/fxml/"+fieldNew.getText()+".fxml\"));\n" +
                            "      "+fieldNew.getText()+"Controller pantalla"+fieldNew.getText()+" = loader"+fieldNew.getText()+".getController();\n" +
                            "      loader"+fieldNew.getText()+".setRoot(null);\n" +
                            "      loader"+fieldNew.getText()+".setController(null);\n" +
                            "      pane"+fieldNew.getText()+" = loader"+fieldNew.getText()+".load(getClass().getResourceAsStream(\"/fxml/"+fieldNew.getText()+".fxml\"));\n" +
                            "      pantalla"+fieldNew.getText()+" = loader"+fieldNew.getText()+".getController();\n" +
                            "\n" +
                            "    }");


                    fieldNew.setText("");
                }
            }

        });
    }
    private class CustomFocusTraversalPolicy extends FocusTraversalPolicy {
        Vector<Component> components;

        public CustomFocusTraversalPolicy(Vector<Component> componentsInput) {
            components = componentsInput;
        }

        public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldTitle)) {
                return fieldMain;
            } else if (aComponent.equals(fieldMain)) {
                return fieldNew;
            }
            else if (aComponent.equals(fieldNew)) {
                return fieldTitle;
            }
            return fieldMain;
        }

        public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldTitle)) {
                return fieldNew;
            }
            else if (aComponent.equals(fieldNew)) {
                return fieldMain;
            }
             else if (aComponent.equals(fieldMain)) {
                return fieldTitle;
            }
            return fieldMain;
        }

        public Component getDefaultComponent(Container focusCycleRoot) {
            return fieldTitle;
        }

        public Component getLastComponent(Container focusCycleRoot) {
            return fieldNew;
        }

        public Component getFirstComponent(Container focusCycleRoot) {
            return fieldTitle;
        }
    }

}
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;


public class Main {
    static JTextField labelCustom;
    static JTextField fieldInt;
    static JTextField fieldString;
    static JTextField fieldDate;
    static JTextField fieldDouble;
    static JTextField fieldBoolean;
    static JTextField fieldCustom;
    static String error;
    public static void main(String[] args) throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {
        // es | en | fr
        String loc = "en";
        error = null;
        String placeholderText = null;
        String resetButtonText = null;
        switch (loc)
        {
            case "es":
                placeholderText= "Clase personalizada";
                error="Error: Debes introducir un nombre para la clase personalizada";
                resetButtonText="Eliminar todo";
                break;
            case "en":
                placeholderText= "Custom class";
                error="Error: You must insert a name in the custom class";
                resetButtonText="Delete all";
                break;
            case "fr":
                placeholderText= "Classe personnalisée";
                error="\nErreur: vous devez entrer un nom pour la classe personnalisée";
                resetButtonText="Removeur";
                break;
        }
        JFrame f = new JFrame("Easy Pojo Generator by Luis Miguel Congosto");
        JLabel labelInt = new JLabel();
        JLabel labelString = new JLabel();
        JLabel labelDate = new JLabel();
        JLabel labelDouble = new JLabel();
        JLabel labelBoolean = new JLabel();

        labelCustom = new JTextField();
        fieldInt = new JTextField();
        fieldString = new JTextField();
        fieldDate = new JTextField();
        fieldDouble = new JTextField();
        fieldBoolean = new JTextField();
        fieldCustom = new JTextField();

        JTextArea output = new JTextArea();
        JButton resetButton = new JButton(resetButtonText);

        labelInt.setText("Int");
        labelString.setText("String");
        labelDate.setText("Date");
        labelDouble.setText("Double");
        labelBoolean.setText("Boolean");

        labelInt.setBounds(5, 20, 100, 20);
        labelString.setBounds(105, 20, 100, 20);
        labelDate.setBounds(205, 20, 100, 20);
        labelDouble.setBounds(305, 20, 100, 20);
        labelBoolean.setBounds(405, 20, 100, 20);
        labelCustom.setBounds(505, 20, 100, 20);

        fieldInt.setBounds(5, 50, 100, 20);
        fieldString.setBounds(105, 50, 100, 20);
        fieldDate.setBounds(205, 50, 100, 20);
        fieldDouble.setBounds(305, 50, 100, 20);
        fieldBoolean.setBounds(405, 50, 100, 20);
        fieldCustom.setBounds(505, 50, 100, 20);

        output.setBounds(5, 80, 600, 350);
        resetButton.setBounds(5, 435, 600, 45);

        Vector<Component> components = new Vector<Component>(7);
        components.add(labelCustom);
        components.add(fieldInt);
        components.add(fieldDate);
        components.add(fieldDouble);
        components.add(fieldBoolean);
        components.add(fieldCustom);
        components.add(fieldString);

        f.setFocusTraversalPolicy(new CustomFocusTraversalPolicy(components));
        f.setResizable(false);
        f.add(labelInt);
        f.add(labelString);
        f.add(labelDate);
        f.add(labelDouble);
        f.add(labelBoolean);
        f.add(labelCustom);

        f.add(fieldInt);
        f.add(fieldString);
        f.add(fieldDate);
        f.add(fieldDouble);
        f.add(fieldBoolean);
        f.add(fieldCustom);
        f.add(resetButton);

        TextPrompt placeholder = new TextPrompt(placeholderText, labelCustom);
        placeholder.changeAlpha(0.75f);
        placeholder.changeStyle(Font.ITALIC);

        output.setEditable(false);
        f.add(output);
        f.setSize(625, 524);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
        resetButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                output.setText("");
            }
        });

        fieldInt.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldInt.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private int "+fieldInt.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate int "+fieldInt.getText()+";");
                    }
                    fieldInt.setText("");
                }
            }

        });

        fieldString.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldString.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private String "+fieldString.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate String "+fieldString.getText()+";");
                    }
                    fieldString.setText("");
                }
            }

        });

        fieldDate.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldDate.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private LocalDate "+fieldDate.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate LocalDate "+fieldDate.getText()+";");
                    }
                    fieldDate.setText("");
                }
            }

        });

        fieldBoolean.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldBoolean.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private boolean "+fieldBoolean.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate boolean "+fieldBoolean.getText()+";");
                    }
                    fieldBoolean.setText("");
                }
            }

        });

        fieldDouble.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldDouble.getText().equals("")){
                    if (output.getText().equals(""))
                    {
                        output.append("private double "+fieldDouble.getText()+";");
                    }
                    else
                    {
                        output.append("\nprivate double "+fieldDouble.getText()+";");
                    }
                    fieldDouble.setText("");
                }
            }
        });

        fieldCustom.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER && !fieldCustom.getText().equals("")){
                    if (labelCustom.getText().equals(""))
                    {
                        JOptionPane.showMessageDialog(null, error);
                    }
                    else {
                        String customClass = labelCustom.getText().substring(0, 1).toUpperCase() + labelCustom.getText().substring(1).toLowerCase();
                        if (output.getText().equals("")) {
                            output.append("private " + customClass + " " + fieldCustom.getText() + ";");
                        } else {
                            output.append("\nprivate " + customClass + " " + fieldCustom.getText() + ";");
                        }
                        fieldCustom.setText("");
                        labelCustom.setText("");
                    }
                }
            }
        });
    }
    public static class CustomFocusTraversalPolicy extends FocusTraversalPolicy {
        Vector<Component> components;

        public CustomFocusTraversalPolicy(Vector<Component> componentsInput) {
            components = componentsInput;
        }

        public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldInt)) {
                return fieldString;
            } else if (aComponent.equals(fieldString)) {
                return fieldDate;
            } else if (aComponent.equals(fieldDate)) {
                return fieldDouble;
            } else if (aComponent.equals(fieldDouble)) {
                return fieldBoolean;
            } else if (aComponent.equals(fieldBoolean)) {
                return labelCustom;
            }
            else if (aComponent.equals(labelCustom)) {
                return fieldCustom;
            }
            else if (aComponent.equals(fieldCustom)) {
                return fieldInt;
            }

            return fieldInt;
        }

        public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {
            if (aComponent.equals(fieldInt)) {
                return fieldCustom;
            } else if (aComponent.equals(fieldCustom)) {
                return labelCustom;
            } else if (aComponent.equals(labelCustom)) {
                return fieldBoolean;
            } else if (aComponent.equals(fieldBoolean)) {
                return fieldDouble;
            } else if (aComponent.equals(fieldDouble)) {
                return fieldDate;
            }
            else if (aComponent.equals(fieldDate)) {
                return fieldString;
            }
            else if (aComponent.equals(fieldString)) {
                return fieldInt;
            }

            return fieldInt;
        }

        public Component getDefaultComponent(Container focusCycleRoot) {
            return fieldInt;
        }

        public Component getLastComponent(Container focusCycleRoot) {
            return fieldCustom;
        }

        public Component getFirstComponent(Container focusCycleRoot) {
            return fieldInt;
        }
    }

}
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GenLauncher {
    public GenLauncher()
    {
        JFrame f = new JFrame("JavaGen Suite");
        JButton pojoGenButton = new JButton("PojoGen");
        pojoGenButton.setBounds(10,10,200,20);
        pojoGenButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                PojoGen pojoGen = new PojoGen();
                f.dispose();
            }
        });
        f.add(pojoGenButton);
        f.setSize(625, 524);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.addWindowListener( new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
    }
}
